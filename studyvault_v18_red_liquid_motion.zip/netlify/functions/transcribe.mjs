
import {json,auth} from "./_lib.mjs";

const MAX_AUDIO_BYTES=4*1024*1024;

export default async function(req){
  const a=await auth(req);
  if(!a)return json({error:"Bitte melde dich erneut an."},401);
  if(req.method!=="POST")return json({error:"Method not allowed"},405);

  const key=process.env.OPENAI_API_KEY;
  if(!key)return json({error:"KI-Audio ist noch nicht konfiguriert."},503);

  let form;
  try{form=await req.formData()}catch{return json({error:"Die Audioaufnahme konnte nicht gelesen werden."},400)}
  const file=form.get("file");
  if(!(file instanceof Blob))return json({error:"Keine Audioaufnahme empfangen."},400);
  if(!file.size)return json({error:"Die Audioaufnahme ist leer."},400);
  if(file.size>MAX_AUDIO_BYTES){
    return json({error:"Die Aufnahme ist zu groß. Bitte halte einen Audio-Bericht unter etwa 3 Minuten und versuche es erneut."},413);
  }

  const fd=new FormData();
  fd.append("file",file,file.name||"audio.m4a");
  fd.append("model",process.env.STUDYVAULT_TRANSCRIBE_MODEL||"gpt-4o-mini-transcribe");
  fd.append("language","de");

  const base=(process.env.OPENAI_BASE_URL||"https://api.openai.com").replace(/\/$/,"");
  let r;
  try{
    r=await fetch(base+"/v1/audio/transcriptions",{
      method:"POST",
      headers:{Authorization:`Bearer ${key}`},
      body:fd
    });
  }catch{
    return json({error:"Die Transkription konnte den KI-Dienst nicht erreichen."},502);
  }

  const j=await r.json().catch(()=>({}));
  if(!r.ok)return json({error:j?.error?.message||"Audio konnte nicht transkribiert werden."},502);
  const text=String(j.text||"").trim();
  if(text.length<10)return json({error:"In der Aufnahme wurde zu wenig verständliche Sprache erkannt."},422);
  return json({text});
}
export const config={path:"/api/transcribe",method:"POST",rateLimit:{windowLimit:10,windowSize:60,aggregateBy:["ip","domain"]}};
